﻿namespace BlackJack
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Init = new Button();
            pot = new TextBox();
            somme = new Label();
            mise = new GroupBox();
            mise_100 = new RadioButton();
            mise_50 = new RadioButton();
            mise_20 = new RadioButton();
            mise_10 = new RadioButton();
            distrib = new Button();
            CarteJoueur = new TextBox();
            CarteCroupier = new TextBox();
            pioche = new Button();
            restez = new Button();
            j = new Label();
            c = new Label();
            mise.SuspendLayout();
            SuspendLayout();
            // 
            // Init
            // 
            Init.BackColor = SystemColors.ActiveBorder;
            Init.Cursor = Cursors.Hand;
            Init.Location = new Point(12, 18);
            Init.Name = "Init";
            Init.Size = new Size(75, 23);
            Init.TabIndex = 0;
            Init.Text = "Init";
            Init.UseVisualStyleBackColor = false;
            Init.Click += Init_Click;
            // 
            // pot
            // 
            pot.BackColor = SystemColors.ActiveBorder;
            pot.Cursor = Cursors.IBeam;
            pot.Location = new Point(107, 18);
            pot.Name = "pot";
            pot.Size = new Size(100, 23);
            pot.TabIndex = 1;
            pot.TextChanged += pot_TextChanged;
            // 
            // somme
            // 
            somme.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            somme.Location = new Point(546, 18);
            somme.Name = "somme";
            somme.Size = new Size(100, 48);
            somme.TabIndex = 2;
            somme.Text = "0000";
            somme.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // mise
            // 
            mise.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mise.AutoSize = true;
            mise.BackColor = Color.DarkSlateGray;
            mise.Controls.Add(mise_100);
            mise.Controls.Add(mise_50);
            mise.Controls.Add(mise_20);
            mise.Controls.Add(mise_10);
            mise.Location = new Point(254, 67);
            mise.Name = "mise";
            mise.Size = new Size(190, 60);
            mise.TabIndex = 3;
            mise.TabStop = false;
            mise.Text = "mise";
            mise.Enter += mise_Enter;
            // 
            // mise_100
            // 
            mise_100.AutoSize = true;
            mise_100.Cursor = Cursors.Hand;
            mise_100.Location = new Point(141, 19);
            mise_100.Name = "mise_100";
            mise_100.Size = new Size(43, 19);
            mise_100.TabIndex = 3;
            mise_100.Text = "100";
            mise_100.UseVisualStyleBackColor = true;
            // 
            // mise_50
            // 
            mise_50.AutoSize = true;
            mise_50.Cursor = Cursors.Hand;
            mise_50.Location = new Point(98, 19);
            mise_50.Name = "mise_50";
            mise_50.Size = new Size(37, 19);
            mise_50.TabIndex = 2;
            mise_50.Text = "50";
            mise_50.UseVisualStyleBackColor = true;
            // 
            // mise_20
            // 
            mise_20.AutoSize = true;
            mise_20.Cursor = Cursors.Hand;
            mise_20.Location = new Point(55, 19);
            mise_20.Name = "mise_20";
            mise_20.Size = new Size(37, 19);
            mise_20.TabIndex = 1;
            mise_20.Text = "20";
            mise_20.UseVisualStyleBackColor = true;
            // 
            // mise_10
            // 
            mise_10.AutoSize = true;
            mise_10.Checked = true;
            mise_10.Cursor = Cursors.Hand;
            mise_10.Location = new Point(12, 19);
            mise_10.Name = "mise_10";
            mise_10.Size = new Size(37, 19);
            mise_10.TabIndex = 0;
            mise_10.TabStop = true;
            mise_10.Text = "10";
            mise_10.UseVisualStyleBackColor = true;
            mise_10.CheckedChanged += mise_10_CheckedChanged;
            // 
            // distrib
            // 
            distrib.AutoSize = true;
            distrib.BackColor = SystemColors.ActiveBorder;
            distrib.Cursor = Cursors.Hand;
            distrib.Location = new Point(48, 133);
            distrib.Name = "distrib";
            distrib.Size = new Size(100, 40);
            distrib.TabIndex = 4;
            distrib.Text = "Distribution";
            distrib.UseVisualStyleBackColor = false;
            distrib.Click += distrib_Click;
            // 
            // CarteJoueur
            // 
            CarteJoueur.BackColor = SystemColors.ActiveBorder;
            CarteJoueur.Location = new Point(12, 192);
            CarteJoueur.Multiline = true;
            CarteJoueur.Name = "CarteJoueur";
            CarteJoueur.Size = new Size(136, 178);
            CarteJoueur.TabIndex = 5;
            CarteJoueur.TextChanged += CarteJoueur_TextChanged;
            // 
            // CarteCroupier
            // 
            CarteCroupier.BackColor = SystemColors.ActiveBorder;
            CarteCroupier.Location = new Point(546, 192);
            CarteCroupier.Multiline = true;
            CarteCroupier.Name = "CarteCroupier";
            CarteCroupier.Size = new Size(136, 178);
            CarteCroupier.TabIndex = 6;
            // 
            // pioche
            // 
            pioche.AutoSize = true;
            pioche.BackColor = SystemColors.ActiveBorder;
            pioche.Cursor = Cursors.Hand;
            pioche.Location = new Point(299, 133);
            pioche.Name = "pioche";
            pioche.Size = new Size(100, 40);
            pioche.TabIndex = 7;
            pioche.Text = "Tirer une carte";
            pioche.UseVisualStyleBackColor = false;
            pioche.Click += pioche_Click;
            // 
            // restez
            // 
            restez.AutoSize = true;
            restez.BackColor = SystemColors.ActiveBorder;
            restez.Cursor = Cursors.Hand;
            restez.Location = new Point(546, 133);
            restez.Name = "restez";
            restez.Size = new Size(100, 40);
            restez.TabIndex = 8;
            restez.Text = "Reste";
            restez.UseVisualStyleBackColor = false;
            restez.Click += restez_Click;
            // 
            // j
            // 
            j.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            j.Location = new Point(154, 231);
            j.Name = "j";
            j.Size = new Size(100, 100);
            j.TabIndex = 9;
            j.Text = "Joueur";
            j.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // c
            // 
            c.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            c.Location = new Point(419, 231);
            c.Name = "c";
            c.Size = new Size(121, 100);
            c.TabIndex = 10;
            c.Text = "Croupier";
            c.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateGray;
            ClientSize = new Size(694, 450);
            Controls.Add(c);
            Controls.Add(j);
            Controls.Add(restez);
            Controls.Add(pioche);
            Controls.Add(CarteCroupier);
            Controls.Add(CarteJoueur);
            Controls.Add(distrib);
            Controls.Add(mise);
            Controls.Add(somme);
            Controls.Add(pot);
            Controls.Add(Init);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "BlackJack";
            Load += Form1_Load;
            mise.ResumeLayout(false);
            mise.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Init;
        private TextBox pot;
        private Label somme;
        private GroupBox mise;
        private RadioButton mise_20;
        private RadioButton mise_10;
        private RadioButton mise_100;
        private RadioButton mise_50;
        private Button distrib;
        private TextBox CarteJoueur;
        private TextBox CarteCroupier;
        private Button pioche;
        private Button restez;
        private Label j;
        private Label c;
    }
}