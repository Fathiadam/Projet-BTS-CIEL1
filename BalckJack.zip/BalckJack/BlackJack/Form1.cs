using System.Reflection.Metadata;

namespace BlackJack
{
    public partial class Form1 : Form
    {
        int reste = 0;
        int SommeJoueur = 0, SommeCroupier = 0, tempo = 0;
        string tempMise;

        Random alea = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Init_Click(object sender, EventArgs e)
        {
            reste = int.Parse(pot.Text);
            somme.Text = reste.ToString();
        }

        private void distribution()
        {
            for (int i = 0; i < 2; i++)
            {
                tempo = alea.Next(1, 14);
                if (tempo == 14)
                {
                    tempo = 1;
                }
                else if (tempo == 13 || tempo == 12 || tempo == 11)
                {
                    tempo = 10;
                }
                CarteJoueur.AppendText(tempo.ToString() + System.Environment.NewLine);
                SommeJoueur += tempo;
            }

            for (int i = 0; i < 1; i++)
            {
                tempo = alea.Next(1, 14);
                if (tempo == 14)
                {
                    tempo = 1;
                }
                else if (tempo == 13 || tempo == 12 || tempo == 11)
                {
                    tempo = 10;
                }
                CarteCroupier.AppendText(tempo.ToString() + System.Environment.NewLine);
                SommeCroupier += tempo;
            }
        }

        private void distrib_Click(object sender, EventArgs e)
        {
            distribution();

        }

        private void pioche_Click(object sender, EventArgs e)
        {
            tempo = alea.Next(1, 14);

            if (tempo == 14)
            {
                tempo = 1;
            }
            else if (tempo == 13 || tempo == 12 || tempo == 11)
            {
                tempo = 10;
            }
            CarteJoueur.AppendText(tempo.ToString() + System.Environment.NewLine);
            SommeJoueur += tempo;

            if (SommeJoueur > 21)
            {
                mise_moins();
                MessageBox.Show("Vous avez perdu", "Defaite");
                CarteJoueur.Clear();
                CarteCroupier.Clear();
                SommeCroupier = 0;
                SommeJoueur = 0;
            }
            else if (SommeJoueur == 21)
            {
                mise_plus();
                MessageBox.Show("Vous avez gagner", "Victoire");
                CarteJoueur.Clear();
                CarteCroupier.Clear();
                SommeCroupier = 0;
                SommeJoueur = 0;
            }

        }

        private void restez_Click(object sender, EventArgs e)
        {
            while (SommeCroupier < 21 && SommeCroupier < SommeJoueur)
            {
                tempo = alea.Next(1, 14);
                if (tempo == 14)
                {
                    tempo = 1;
                }
                else if (tempo == 13 || tempo == 12 || tempo == 11)
                {
                    tempo = 10;
                }
                CarteCroupier.AppendText(tempo.ToString() + System.Environment.NewLine);
                SommeCroupier += tempo;
            }

            if (SommeCroupier > 21)
            {
                mise_plus();
                MessageBox.Show("Vous avez gagner", "Victoire");
                CarteJoueur.Clear();
                CarteCroupier.Clear();
                SommeCroupier = 0;
                SommeJoueur = 0;
            }
            else if (SommeJoueur > SommeCroupier)
            {
                mise_plus();
                MessageBox.Show("Vous avez gagner", "Victoire");
                CarteJoueur.Clear();
                CarteCroupier.Clear();
                SommeCroupier = 0;
                SommeJoueur = 0;
            }
            else if (SommeJoueur < SommeCroupier)
            {
                mise_moins();
                MessageBox.Show("Vous avez perdu", "Defaite");
                CarteJoueur.Clear();
                CarteCroupier.Clear();
                SommeCroupier = 0;
                SommeJoueur = 0;
            }
            else if (SommeJoueur == SommeCroupier)
            {
                MessageBox.Show("Vous etes a egalite", "Egalite");
                CarteJoueur.Clear();
                CarteCroupier.Clear();
                SommeCroupier = 0;
                SommeJoueur = 0;
            }
        }

        private void mise_moins()
        {
            if (mise_10.Checked == true)
            {
                reste = int.Parse(somme.Text) - 10;
                somme.Text = reste.ToString();
            }
            else if (mise_20.Checked == true)
            {
                reste = int.Parse(somme.Text) - 20;
                somme.Text = reste.ToString();
            }
            else if (mise_50.Checked == true)
            {
                reste = int.Parse(somme.Text) - 50;
                somme.Text = reste.ToString();
            }
            else if (mise_100.Checked == true)
            {
                reste = int.Parse(somme.Text) - 100;
                somme.Text = reste.ToString();
            }
        }

        private void mise_plus()
        {
            if (mise_10.Checked == true)
            {
                reste = int.Parse(somme.Text) + 10;
                somme.Text = reste.ToString();
            }
            else if (mise_20.Checked == true)
            {
                reste = int.Parse(somme.Text) + 20;
                somme.Text = reste.ToString();
            }
            else if (mise_50.Checked == true)
            {
                reste = int.Parse(somme.Text) + 50;
                somme.Text = reste.ToString();
            }
            else if (mise_100.Checked == true)
            {
                reste = int.Parse(somme.Text) + 100;
                somme.Text = reste.ToString();
            }
        }





        private void mise_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pot_TextChanged(object sender, EventArgs e)
        {

        }

        private void CarteJoueur_TextChanged(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void mise_10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void score_j_Click(object sender, EventArgs e)
        {

        }
    }
}